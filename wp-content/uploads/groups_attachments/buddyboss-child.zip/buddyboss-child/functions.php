<?php
// functions added here will load IN ADDITION to functions from the parent theme's functions.php.

;?>